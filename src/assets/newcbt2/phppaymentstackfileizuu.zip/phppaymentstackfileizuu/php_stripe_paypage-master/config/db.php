<?php
  // DB Params
  define("DB_HOST", "localhost");
  define("DB_USER", "YOURUSERNAME");
  define("DB_PASS", "YOURPASSWORD");
  define("DB_NAME", "YOURDATABASENAME");